package types

const (
	QueryGetName  = "get-name"
	QueryListName = "list-name"
)

const (
	QueryGetWhois  = "get-whois"
	QueryListWhois = "list-whois"
)
