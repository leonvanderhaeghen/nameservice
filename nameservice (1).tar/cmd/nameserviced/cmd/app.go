package cmd

const appName = "nameservice"
